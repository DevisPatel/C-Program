#include<stdio.h>
#include<conio.h>
#include<math.h>
void main()
{
	float a,b,c,d,x,y,r1,r2;
	clrscr();
	printf("enter a value of a");
	scanf("%f",&a);
	printf("enter a value of b");
	scanf("%f",&b);
	printf("enter a value of c");
	scanf("%f",&c);
	printf("a*x*x+b*x+c");
	d=(b*b -4*a*c);
	if(d>0)

	{
	      r1=(-b+sqrt(d)/2*a);
	      r2=(-b+sqrt(d)/2*a);

	}
	else
	{
	printf("roots are not possible");
	}
getch();
}