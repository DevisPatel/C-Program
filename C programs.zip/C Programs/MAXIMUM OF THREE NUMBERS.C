#include<stdio.h>
#include<conio.h>
void main()
{
	int a,b,c;
	clrscr();
	printf("enter a value of a");
	scanf("%d",&a);
	printf("enter a value of b");
	scanf("%d",&b);
	printf("enter a value of c");
	scanf("%d",&c);
	if(a>b)
	{
		if(a>c)
		{
		printf("a is maximum");
		}
		else
		{
		printf("c is maximum");
		}
	}
	else
	{
		if(b>c)
		{
		printf("b is maximum");
		}
		else
		{
		printf("c is maximum");
		}
	}
	getch();
}
