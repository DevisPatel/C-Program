#include<stdio.h>
#include<conio.h>
void main()
{
	int a;

	printf("enter a year");
	scanf("%d",&a);
	if(a%4==0)

		{
		printf("this is leap year");
		}
	else
		{
		printf("this is not a leap year");
		}
getch();
}
