#include<stdio.h>
#include<conio.h>
void main()
{
	int a,b;
	clrscr();
	printf("enter a value of a");
	scanf("%d",&a);
	printf("enter a value of b");
	scanf("%d",&b);
	printf("value of a is %d",(a+b)-a);
	printf("value of b is %d",(b+a)-b);
getch();
}