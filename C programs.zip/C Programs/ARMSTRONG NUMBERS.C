#include<stdio.h>
#include<conio.h>
void main()
{
	int a,b,c,d,f;
	clrscr();
	printf("enter a value of d\n");
	scanf(" \n %d",&d);
	printf("enter a value of a,b and c \n");
	scanf(" \n %d %d %d",&a,&b,&c);
	f =  a*a*a + b*b*b + c*c*c;
	if(d==f)
	{
	printf("this is armstrong number");
	}
	else
	{
	printf("this is not a armstrong number");
	}
getch();
}