#include<stdio.h>
#include<conio.h>
void main()
{
	int f=1,t,l,n,i;
	clrscr();
	printf("how many numbers you want to print \n");
	scanf("%d",&t);
	printf("\n \n %d fibonacci numbers \n",t);
	printf("%d",f);
	printf("%d",f);
	n=f;
	l=f;
	for(i=2;i<t;i++)
	{
		f=l+n;
		l=n;
		n=f;
		printf(" %d ",f);
	}
	getch();
}



