#include<stdio.h>
#include<conio.h>
void main()
{
	int i,b;
	clrscr();
	printf("enter year");
	scanf("%d",&b);
	for(i=0;i<=b;i++)
	{
	if(i%4==0)
	{
	printf("\n leap year is %d",i);
	}
	}
getch();
}

