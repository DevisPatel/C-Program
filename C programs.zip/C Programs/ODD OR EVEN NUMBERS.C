#include<stdio.h>
#include<conio.h>
void main()
{
	int a;
	clrscr();
	printf("enter the value of a");
	scanf("%d",&a);
	if(a%2==1)
	{
		printf("the given number is odd");
	}
	else
	{
		printf("the given number is even");
	}
getch();
}