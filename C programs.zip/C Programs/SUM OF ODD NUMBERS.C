#include<stdio.h>
#include<conio.h>
void main()
{
	int i,sum=0;
	clrscr();
	for(i=2;i<100;i++)
	{
		if(i%2==1)
		{
		sum=sum+i;
		}
		else
		{
		printf(" ");
		}
	printf(" ");
	}
	printf("sum of number is=%d",sum);

getch();
}