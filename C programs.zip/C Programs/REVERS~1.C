#include<stdio.h>
#include<conio.h>
void main()
{
	int a,b,c,x,y;
	clrscr();
	printf("enter a value of a \n");
	scanf("%d",&a);
	printf("enter a value of b \n");
	scanf("%d",&b);
	printf("enter a value of c \n");
	scanf("%d",&c);
	printf("x = %d %d %d \n",a,b,c);
	printf("y = %d %d %d \n",c,b,a);
getch();
}
