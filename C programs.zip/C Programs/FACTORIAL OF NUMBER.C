#include<stdio.h>
#include<conio.h>
void main()
{
	int a,i;
	clrscr();
	printf("enter a value");
	scanf("%d",&a);
	for(i=a-1;i>0;i--)
	{
	a=a*i;
	}
	printf("%d",a);
getch();
}