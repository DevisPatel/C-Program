#include<stdio.h>
#include<conio.h>
void swap(int a,int b)
{
	int temp;
	temp = a;
	a = b;
	b = temp;
	printf("enter value of exchange function \n");
	printf("a = %d  b = %d \n",a,b);
}

	void main()
{
	int x,y;
	clrscr();
	printf("enter value of x and y \n");
	scanf("%d  %d",&x,&y);
	swap(x,y);
	printf(" value of function after exchanging \n");
	printf("x = %d  y = %d \n",x,y);
	getch();
}