#include<stdio.h>
#include<conio.h>

int power(int a,int b);
void main()
{
	int x,y,ans;
	clrscr();
	printf("enetr a value of integers \n");
	scanf("%d %d",&x,&y);
	ans = power(x,y);
	printf("%d ^ %d  using recursion is = %d \n",x,y,ans);
	getch();
}

	int power(int a,int b)
	{
	if (b == 0)
	return 1;
	else
	return a * power(a,b-1);
	}
