#include<stdio.h>
#include<conio.h>
char check_leap(int year);
void main()
{
	int year;
	clrscr();
	printf("enter year \n");
	scanf("%d",&year);
	if(check_leap(year) == 't')
	{
	printf("year %d is leap year \n",year);
	}
	else
	{
	printf("year %d is not leap year \n",year);
	}
	getch();
}

	char check_leap(int year)
	{
	if (year%4 == 0)
	return 't';
	else
	return 'f';
	}
