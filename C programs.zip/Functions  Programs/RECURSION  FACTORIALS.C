#include<stdio.h>
#include<conio.h>
long int fact(int a);
void main()
{
	int x;
	int ans;
	clrscr();
	printf("enter a value of x");
	scanf("%d",&x);
	ans = fact(x);
	printf("answer of factorial %d using function recursion is %d",x,ans);
	getch();
}

	long int fact(int a)
{
	if(a==1)
	{
	return 1;
	}
	else
	{
	return a * fact(a-1);
	}
}