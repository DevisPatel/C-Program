#include<stdio.h>
#include<conio.h>
 void add(int a,int b);
 void main()
 {
	int i,j;
	clrscr();
	printf("enter two integer numbers \n ");
	scanf("%d %d",&i,&j);
	add(i,j);
	getch();
 }

	void add(int a,int b)
	{
	int c;
	c = a + b;
	printf("sum of %d and %d is = %d",a,b,c);
	}
