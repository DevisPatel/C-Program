#include<stdio.h>
#include<conio.h>
void main()
{
	int i,a;
	char c;

	clrscr();
	c='y';
       while(c=='y')
      {
	for(i=0;i<5;i++)
	{
		printf("a");

	}
	scanf("%s",&c);
	clrscr();

       }

}

