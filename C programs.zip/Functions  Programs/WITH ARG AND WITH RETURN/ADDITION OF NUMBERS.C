#include<stdio.h>
#include<conio.h>
int sum(int a,int b);
void main()
{
	int x,y;
	int ans;
	clrscr();
	printf("\n enter a value of x and y \n");
	scanf("%d %d",&x,&y);
	ans = sum(x,y);
	printf("\n sum of %d and %d using function is %d\n",x,y,ans);
	getch();
}
	int sum(int a,int b)
	{
	return a + b;
	}




