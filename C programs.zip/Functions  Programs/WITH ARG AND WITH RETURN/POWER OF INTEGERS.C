#include<stdio.h>
#include<conio.h>

int power(int a,int b);
void main()
{
	int x,y,ans;
	clrscr();
	printf("enetr a value of integers \n");
	scanf("%d %d",&x,&y);
	ans = power(x,y);
	printf("%d ^ %d  using function is = %d \n",x,y,ans);
	getch();
}

	int power(int a,int b)
	{
	int i,c=1;
	for(i=1;i<=b;i++)
	{
	c = c*a;
	}
	return c;
	}