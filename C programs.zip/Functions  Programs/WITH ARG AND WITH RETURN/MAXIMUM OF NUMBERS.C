#include<stdio.h>
#include<conio.h>
int max(int a,int b,int c);
void main()
{
	int x,y,z;
	int ans;
	clrscr();
	{
	printf("enetr a value off x,y and z  \n");
	scanf("%d %d %d",&x,&y,&z);
	ans=max(x,y,z);
	printf("maximum of %d, %d, %d using function is %d \n",x,y,z,ans);
	}
	getch();
}

	int max(int a,int b,int c)
{
	int max=a;

	if(b>max)
	max=b;
	if(c>max)
	max=c;
	return max;
}