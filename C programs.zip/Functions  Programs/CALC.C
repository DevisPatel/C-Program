#include<stdio.h>
#include<conio.h>
int sum(int x,int y);
int sub(int x,int y);
int mul(int x,int y);
int div(int x,int y);
void main()
{
	int a,b;
	char op;
	clrscr();
	printf("enter a value of two integers \n");
	scanf("%d %d",&a,&b);
	printf("enter character \n");
	scanf("%c",&op);
	getchar();
	switch(op)
	{
	case 1:
		printf("sum=%d",sum(a,b));
		break;
	case 2:
		printf("sub=%d",sub(a,b));
		break;
	case 3:
		printf("mul=%d",mul(a,b));
		break;
	case 4:
		printf("div=%d",div(a,b));
		break;
	default:
		printf("invalid choice");
	}
	getch();
}

	int sum(int x,int y)
	{
	return (x+y);
	}
	int sub(int x,int y)
	{
	return (x-y);
	}
	int mul(int x,int y)
	{
	return (x*y);
	}
	int div(int x,int y)
	{
	return (x/y);
	}

