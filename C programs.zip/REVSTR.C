#include<stdio.h>
#include<conio.h>

	void reverse()
	{
		char a[6];
		printf("\n enter character \n");
		scanf("%c",&a);
		if(a!='\n')
		{
		reverse();
		printf("\n %c",a);
		}
	}

	void main()
	{
	clrscr();
	reverse();
	getch();
	}