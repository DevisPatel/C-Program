#include<stdio.h>
#include<conio.h>

	void main()
	{
	clrscr();
	printf("\n current time is %s \n",__TIME__);
	getch();
	}