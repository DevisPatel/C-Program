#include<stdio.h>
#include<conio.h>
#include<string.h>

	void main()
	{
		int strncmp(const char *s1[6], const char *s2[6],size_t 6);
		clrscr();
		printf("\n enter name \n");
		scanf("%c",&(*s1));
		getch();
	}

