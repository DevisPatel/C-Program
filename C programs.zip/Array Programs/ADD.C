#include<stdio.h>
#include<conio.h>

void main()
{
	int i,j,a[3][3],b[3][3],c[3][3];
	clrscr();
	printf("\n enter fiesrt array \n");
	for(i=0;i<3;i++)
	{
	for(j=0;j<3;j++)
	{
	scanf("%d",&a[i][j]);
	}
	}
	printf("\n enter secon array");
	for(i=0;i<3;i++)
	{
	for(j=0;j<3;j++)
	{
	scanf("%d",&b[i][j]);
	}
	}

	for(i=0;i<3;i++)
	{
	for(j=0;j<3;j++)
	{
	c[i][j]=a[i][j]+b[i][j];
	printf("\n final array is %d \n",c[i][j]);
	}
	}
	getch();
	}