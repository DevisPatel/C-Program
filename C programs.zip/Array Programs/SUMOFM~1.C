#include<stdio.h>
#include<conio.h>
void main()
{
	int a[3][3],b[3][3],c[3][3],i,j;
	clrscr();

	printf("enter first matrix A \n ");

	for(i=0;i<3;i++)
	{
	for(j=0;j<3;j++)
	{
	printf("%4d",a[i][j]);
	}
	printf("\n");
	}

	printf("enter second matrix B \n ");

	for(i=0;i<3;i++)
	{
	for(j=0;j<3;j++)
	{
	printf("%4d",b[i][j]);
	}
	printf("\n");
	}


	printf(" matrix C \n ");
	for(i=0;i<3;i++)
	{
	for(j=0;j<3;j++)
	{
	c[i][j] = a[i][j] + b[i][j] ;
	printf("sum of matrix %4d is = ",c[i][j]);
	}

	printf("\n");
	}


	getch();
}