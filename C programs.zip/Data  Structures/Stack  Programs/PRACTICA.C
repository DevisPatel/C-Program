#include<stdio.h>
#include<conio.h>
#define max 5
void main()
{
	int stack[max],top=-1,ele,choice;
	clrscr();
	main:
	printf("enter ypur choice \n");
	scanf("%d",choice);
	switch(choice)
	{
	case 1:
		printf("enter the element to be pushed into stack \n");
		if(top==max-1)
		{
		printf("\n stack overflow \n");
		}
		else
		{
		top = top++;
		stack[top] = ele;
		printf("\n number pushed is %d \n",ele);
		goto main;
		break;

	case 2:
		exit();

	default:
		printf("\n invalid choice \n");
		break;
}
	getch();
}

