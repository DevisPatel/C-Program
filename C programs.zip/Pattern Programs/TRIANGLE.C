#include<stdio.h>
#include<conio.h>
void main()
{
	int i,j;
	clrscr();
	for(i=5;i>=1;i--)
	{
	for(j=1;j<=5;j++)
	{
	if(i<=j)
		printf(" *");
	else
		printf(" ");
	}
	printf("\n \n");
	}
getch();
}