#include<stdio.h>
#include<conio.h>
void main()
{
	int a,i,j;
	a = 1;
	clrscr();
	for(i=5;i>=a;i--)
	{
		for(j=1;j<=i;j++)
		{
			printf(" 0 1",j);
		}
		printf("\n \n");
	}
getch();
}